# Skynet License

This file defines the license policy for the Skynet source tree.

Copyright (c) 2026 Skynet contributors.

## Summary

Skynet is split into two licensing areas:

- Skynet app source code is licensed under GPL-3.0-or-later, with the additional Ecartometer permission below.
- Ecartometer implementation code is proprietary and all rights are reserved.

This summary is not a substitute for the license terms. If a source file carries a more specific SPDX identifier or license notice, that file-level notice controls for that file.

## Skynet App Source

Unless noted otherwise, source files in this repository are licensed under:

```text
SPDX-License-Identifier: GPL-3.0-or-later
```

You may use, study, modify, and redistribute the GPL-covered Skynet app source under the GNU General Public License, version 3 or any later version published by the Free Software Foundation.

If you distribute a modified Skynet app, you must provide the corresponding source code under the same GPL terms. This keeps distributed modifications to the open-source app available to users.

The GPL-covered Skynet app source is provided without warranty, to the maximum extent permitted by applicable law.

## Ecartometer Proprietary Code

Ecartometer implementation code is not licensed under the GPL and is not open source.

The following files and directories are Ecartometer proprietary material when present:

- `src/Skynet.Ecartometer/`
- `src/Skynet.Ecartometer.*`
- `tests/Skynet.Ecartometer.*`
- Any file that explicitly identifies itself as Ecartometer proprietary source.

Ecartometer proprietary material is covered by:

```text
SPDX-License-Identifier: LicenseRef-Skynet-Ecartometer-Proprietary
```

Copyright is reserved by the copyright holder. No permission is granted to copy, modify, redistribute, sublicense, publish, or reuse Ecartometer proprietary material without a separate written license from the copyright holder.

## Additional Permission For Ecartometer Integration

As an additional permission under GPLv3 section 7, the copyright holder of the GPL-covered Skynet app source permits that GPL-covered source to communicate with, link to, load, execute, or be distributed alongside the Ecartometer component, even when the Ecartometer component is distributed under the proprietary terms above.

This additional permission applies only to the GPL-covered Skynet app source. It does not grant any rights to copy, modify, redistribute, sublicense, publish, or reuse Ecartometer proprietary material.

If you modify the GPL-covered Skynet app source and distribute that modified app, your modifications to the GPL-covered source remain subject to GPL-3.0-or-later.

## Third-Party Components

Third-party components keep their own licenses and are not relicensed by this file.

Known third-party licensing areas include:

- Hamlib `rigctld`, `rotctld`, and related Hamlib files: Hamlib GPL/LGPL terms. Bundled Hamlib binaries must be distributed with the required GPL/LGPL notices and source-code availability or written source offer.
- Avalonia packages: MIT license.
- .NET and Microsoft packages, including Microsoft.Data.Sqlite, Microsoft.Extensions.*, and System.IO.Ports: MIT license.
- CommunityToolkit.Mvvm: MIT license.
- SkiaSharp and HarfBuzzSharp packages: MIT license.
- SQLitePCLRaw packages: Apache-2.0 license.
- SQLite native code distributed through SQLitePCLRaw: SQLite public domain or SQLite project terms, as supplied by the upstream package.

Binary distributions should include the applicable third-party license texts, copyright notices, and source-code offers required by those third-party licenses.

## Contributor Licensing

By submitting a contribution to GPL-covered Skynet app source, you agree that the contribution may be distributed under GPL-3.0-or-later with the additional Ecartometer permission in this file, unless a separate written agreement says otherwise.

Contributions to Ecartometer proprietary material require separate written permission from the copyright holder before they can be accepted or used.

## License Text

A copy of the GPL-3.0-or-later license text should be included with source and binary distributions. The standard GPL-3.0 license text is available from the Free Software Foundation:

https://www.gnu.org/licenses/gpl-3.0.en.html

The SPDX entry for GPL-3.0-or-later is available at:

https://spdx.org/licenses/GPL-3.0-or-later.html
